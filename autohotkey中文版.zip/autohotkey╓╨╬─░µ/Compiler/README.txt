This is a version of the AutoIt3 compiler that has been adapted for use with AutoHotkey scripts.

See www.autohotkey.com and www.hiddensoft.com for details.

AutoIt3 Note: See the main AutoIt source.
